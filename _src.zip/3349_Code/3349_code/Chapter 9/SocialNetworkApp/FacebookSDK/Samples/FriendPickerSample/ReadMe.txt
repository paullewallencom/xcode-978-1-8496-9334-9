Friend Picker sample

Demonstrates how to use a FBFriendPickerViewController in the Facebook SDK for iOS.

Build Requirements
iOS 4.0 SDK

Runtime Requirements
iPhone OS 4.0 or later

Using the Sample
Install the Facebook SDK for iOS.
Launch the FriendPickerSample project using Xcode from the <Facebook SDK>/samples/FriendPickerSample directory.

Changes from Previous Versions
1.0 - First release.

