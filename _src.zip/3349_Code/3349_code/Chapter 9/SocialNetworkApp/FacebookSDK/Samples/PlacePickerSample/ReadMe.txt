PlacePickerSample

Demonstrates how to use the FBPlacePickerViewController provided with
the Facebook SDK for iOS.

Build Requirements
iOS 4.0 SDK

Runtime Requirements
iPhone OS 4.0 or later

Using the Sample
Install the Facebook SDK for iOS.
Launch the PlacePickerSample project using Xcode from the
<Facebook SDK>/samples/PlacePickerSample directory.

Changes from Previous Versions
1.0 - First release.

