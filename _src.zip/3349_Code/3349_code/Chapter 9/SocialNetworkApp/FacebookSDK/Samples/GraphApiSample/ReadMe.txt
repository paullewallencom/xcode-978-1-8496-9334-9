Graph Api sample

Demonstrates the basics of how to make a singleton or batch request using the Facebook SDK for IOS.

Build Requirements
iOS 4.0 SDK

Runtime Requirements
iPhone OS 4.0 or later

Using the Sample
Install the Facebook SDK for iOS.
Launch the GraphApiSample project using Xcode from the <Facebook SDK>/samples/GraphApiSample directory.

Changes from Previous Versions
1.0 - First release.


