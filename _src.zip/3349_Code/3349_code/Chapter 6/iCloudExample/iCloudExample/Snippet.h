//
//  Snippet.h
//  iCloudExample
//
//  Created by Steven Daniel on 08/11/12.
//  Copyright (c) 2012 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Snippet : UIDocument

@property (nonatomic, strong) NSString  *docContent;

@end
