//
//  ViewController.h
//  TransitionsExample
//
//  Created by Steven F Daniel on 20/11/12.
//  Copyright (c) 2012 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

// Declare the Getters and Setters for each of our objects.
@property (weak, nonatomic) IBOutlet UIImageView  *imageView;

@end
